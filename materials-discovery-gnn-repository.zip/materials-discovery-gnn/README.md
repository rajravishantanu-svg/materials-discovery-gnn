# Materials Discovery with Graph Neural Networks

A research prototype for predicting crystalline materials' band gaps from crystal structures using graph neural networks (GNNs) and data from the [Materials Project](https://materialsproject.org/).

> **Status:** Experimental research code. Validate the dataset, model design, and metrics before using predictions for scientific or engineering decisions.

## Overview

This repository provides a reproducible starting point for:
1. Retrieving materials with band-gap and stability filters from the Materials Project API.
2. Converting crystal structures into graphs (atoms = nodes, neighbor relationships = edges).
3. Encoding interatomic distances with radial basis function (RBF) edge features.
4. Training a graph neural network to regress band gap (eV).
5. Evaluating on a held-out test set and saving a prediction-vs-actual plot and model checkpoint.

The included baseline uses a GCN. It is a starting point—not a claim that this architecture is state of the art.

## Repository structure

```text
materials-discovery-gnn/
├── README.md
├── requirements.txt
├── .gitignore
├── .env.example
└── src/
    └── train.py
```

## Requirements

- Python 3.10 or 3.11 recommended
- A Materials Project account and API key
- CPU works for small experiments; a CUDA-enabled PyTorch installation can be used for GPU training

Install the dependencies:

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -r requirements.txt
```

PyTorch and PyTorch Geometric installation can depend on your operating system and CUDA version. If the default installation fails, follow the official [PyTorch installation selector](https://pytorch.org/get-started/locally/) and [PyG installation guide](https://pytorch-geometric.readthedocs.io/en/latest/install/installation.html).

## Configure your API key

Copy `.env.example` to `.env` and add your Materials Project API key:

```env
MP_API_KEY=your_materials_project_api_key
```

The script reads the key from the environment. **Never commit `.env` or paste API keys into source code.** If a real key was previously committed or shared publicly, revoke/rotate it in your Materials Project account.

## Run

From the repository root:

```bash
python src/train.py --n-materials 500 --epochs 30 --model gcn
```

Useful options:

```bash
python src/train.py --help
```

The script writes outputs to `outputs/`:
- `metrics.json` — test MAE and R²
- `predictions.png` — predicted versus actual band gaps
- `model.pt` — trained model state and normalization metadata

## Method

- **Target:** Materials Project band gap, in eV.
- **Data filter:** band gap between 0.1 and 10 eV and energy above hull between 0 and 0.1 eV, matching the initial experiment's intended filters.
- **Graph:** atomic number is the node input; periodic neighbors within the cutoff radius form directed edges.
- **Edge features:** Gaussian/RBF expansion of neighbor distances.
- **Model:** atom embedding → GCN layers → mean graph pooling → regression head.
- **Split:** train/validation/test split with a fixed random seed. Target scaling is fitted on the training subset only.

## Important limitations

- The current baseline uses GCN layers, which do not consume the distance edge features. The RBF features are retained in the graph representation for future edge-aware architectures.
- Random splitting can place chemically similar or related structures in different splits. Consider composition-, prototype-, or time-based splits for more rigorous evaluation.
- The Materials Project dataset and API may change. Record the retrieval date, API query, and material IDs for reproducibility.
- Results depend on sample size, filters, random seed, model settings, and hardware. Report measured metrics from your own run; do not treat example values as validated performance.
- This repository predicts band gaps for structures represented in the fetched dataset. It is not a validated materials-discovery or experimental-design system.

## Data and attribution

Materials data are retrieved through the Materials Project API. Please follow the Materials Project's current citation and data-use requirements when publishing work based on retrieved data: https://materialsproject.org/.

## Reproducibility

For a research run, save the command, package versions, retrieval date, random seed, and Materials Project material IDs alongside the outputs. Do not upload API keys or private data.

## License

This project is provided under the MIT License; see `LICENSE`.
