"""Train a baseline GCN to predict Materials Project band gaps."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from mp_api.client import MPRester
from pymatgen.core import Structure
from sklearn.metrics import mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from torch import nn
from torch.nn import functional as F
from torch_geometric.data import Data
from torch_geometric.loader import DataLoader
from torch_geometric.nn import GCNConv, global_mean_pool
from tqdm import tqdm


def fetch_materials(api_key: str, n_materials: int) -> list[dict]:
    """Fetch a bounded set of materials with structures and band gaps."""
    fields = ["material_id", "structure", "band_gap", "energy_above_hull"]
    with MPRester(api_key) as mpr:
        docs = mpr.materials.summary.search(
            band_gap=(0.1, 10.0),
            energy_above_hull=(0.0, 0.1),
            fields=fields,
            chunk_size=min(1000, n_materials),
        )
    rows = []
    for doc in docs[:n_materials]:
        if doc.structure is None or doc.band_gap is None:
            continue
        rows.append({
            "material_id": str(doc.material_id),
            "structure": doc.structure,
            "band_gap": float(doc.band_gap),
        })
    if not rows:
        raise RuntimeError("No materials returned. Check the API key, query, and API access.")
    return rows


def rbf_expand(distances: np.ndarray, cutoff: float, n_features: int) -> np.ndarray:
    centers = np.linspace(0.0, cutoff, n_features, dtype=np.float32)
    gamma = 1.0 / (2.0 * 0.5**2)
    return np.exp(-gamma * (distances[:, None] - centers[None, :]) ** 2).astype(np.float32)


def structure_to_graph(structure: Structure, target: float, cutoff: float = 5.0,
                       rbf_dim: int = 16) -> Data:
    """Represent a periodic crystal as a graph using pymatgen's neighbor list."""
    atomic_numbers = np.asarray([site.specie.Z for site in structure], dtype=np.int64)
    center, neighbor, _, distances = structure.get_neighbor_list(cutoff)
    if len(center):
        edge_index = torch.tensor(np.vstack([center, neighbor]), dtype=torch.long)
        edge_attr = torch.tensor(rbf_expand(np.asarray(distances), cutoff, rbf_dim))
    else:
        edge_index = torch.empty((2, 0), dtype=torch.long)
        edge_attr = torch.empty((0, rbf_dim), dtype=torch.float32)

    return Data(
        x=torch.tensor(atomic_numbers, dtype=torch.long),
        edge_index=edge_index,
        edge_attr=edge_attr,
        y=torch.tensor([target], dtype=torch.float32),
        num_nodes=len(structure),
    )


class BandGapGCN(nn.Module):
    def __init__(self, max_atomic_number: int = 119, embedding_dim: int = 64,
                 hidden_dim: int = 64, num_layers: int = 2, dropout: float = 0.1):
        super().__init__()
        self.embedding = nn.Embedding(max_atomic_number, embedding_dim)
        self.convs = nn.ModuleList()
        self.norms = nn.ModuleList()
        for i in range(num_layers):
            self.convs.append(GCNConv(embedding_dim if i == 0 else hidden_dim, hidden_dim))
            self.norms.append(nn.BatchNorm1d(hidden_dim))
        self.dropout = dropout
        self.head = nn.Sequential(
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim // 2, 1),
        )

    def forward(self, data):
        x = self.embedding(data.x)
        for conv, norm in zip(self.convs, self.norms):
            x = conv(x, data.edge_index)
            x = norm(x)
            x = F.relu(x)
            x = F.dropout(x, p=self.dropout, training=self.training)
        x = global_mean_pool(x, data.batch)
        return self.head(x).view(-1)


def split_and_scale(graphs: list[Data], seed: int = 42):
    if len(graphs) < 10:
        raise ValueError(f"Need at least 10 valid graphs; received {len(graphs)}.")
    train, temp = train_test_split(graphs, test_size=0.3, random_state=seed)
    val, test = train_test_split(temp, test_size=2 / 3, random_state=seed)

    scaler = StandardScaler()
    train_y = np.array([g.y.item() for g in train], dtype=np.float32).reshape(-1, 1)
    scaler.fit(train_y)
    for subset in (train, val, test):
        for graph in subset:
            graph.y = torch.tensor(
                scaler.transform([[graph.y.item()]])[0], dtype=torch.float32
            )
    return train, val, test, scaler


def train_model(model, train_graphs, val_graphs, device, epochs, batch_size, learning_rate):
    train_loader = DataLoader(train_graphs, batch_size=batch_size, shuffle=True)
    val_loader = DataLoader(val_graphs, batch_size=batch_size, shuffle=False)
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate, weight_decay=1e-5)
    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, mode="min", patience=8, factor=0.5
    )
    loss_fn = nn.MSELoss()
    best_loss = float("inf")
    best_state = None
    patience = 0
    train_history, val_history = [], []

    model.to(device)
    for epoch in range(1, epochs + 1):
        model.train()
        train_losses = []
        for batch in train_loader:
            batch = batch.to(device)
            optimizer.zero_grad()
            loss = loss_fn(model(batch), batch.y.view(-1))
            loss.backward()
            optimizer.step()
            train_losses.append(loss.item())

        model.eval()
        val_losses = []
        with torch.no_grad():
            for batch in val_loader:
                batch = batch.to(device)
                val_losses.append(loss_fn(model(batch), batch.y.view(-1)).item())

        train_loss = float(np.mean(train_losses))
        val_loss = float(np.mean(val_losses))
        train_history.append(train_loss)
        val_history.append(val_loss)
        scheduler.step(val_loss)
        print(f"Epoch {epoch:03d}/{epochs} | train MSE={train_loss:.5f} | val MSE={val_loss:.5f}")

        if val_loss < best_loss:
            best_loss = val_loss
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
            patience = 0
        else:
            patience += 1
            if patience >= 15:
                print("Early stopping.")
                break

    if best_state is None:
        raise RuntimeError("Training did not produce a model checkpoint.")
    model.load_state_dict(best_state)
    return model, train_history, val_history


def evaluate(model, graphs, scaler, device):
    loader = DataLoader(graphs, batch_size=32, shuffle=False)
    predictions, targets = [], []
    model.eval()
    with torch.no_grad():
        for batch in loader:
            batch = batch.to(device)
            predictions.extend(model(batch).detach().cpu().numpy().tolist())
            targets.extend(batch.y.view(-1).detach().cpu().numpy().tolist())
    pred = scaler.inverse_transform(np.asarray(predictions).reshape(-1, 1)).ravel()
    actual = scaler.inverse_transform(np.asarray(targets).reshape(-1, 1)).ravel()
    return actual, pred, {
        "mae_eV": float(mean_absolute_error(actual, pred)),
        "r2": float(r2_score(actual, pred)) if len(actual) > 1 else None,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--n-materials", type=int, default=500)
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--learning-rate", type=float, default=1e-3)
    parser.add_argument("--cutoff", type=float, default=5.0)
    parser.add_argument("--rbf-dim", type=int, default=16)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output-dir", default="outputs")
    args = parser.parse_args()

    api_key = os.getenv("MP_API_KEY")
    if not api_key:
        raise SystemExit("Set MP_API_KEY in your environment before running.")

    torch.manual_seed(args.seed)
    np.random.seed(args.seed)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"Device: {device}")

    rows = fetch_materials(api_key, args.n_materials)
    print(f"Retrieved {len(rows)} materials.")
    graphs, material_ids = [], []
    for row in tqdm(rows, desc="Building crystal graphs"):
        try:
            graphs.append(structure_to_graph(row["structure"], row["band_gap"],
                                              args.cutoff, args.rbf_dim))
            material_ids.append(row["material_id"])
        except Exception as exc:
            print(f"Skipping {row['material_id']}: {exc}")
    if len(graphs) < 10:
        raise SystemExit("Too few valid graphs to train. Increase --n-materials or inspect data.")

    train, val, test, scaler = split_and_scale(graphs, args.seed)
    model = BandGapGCN()
    model, train_history, val_history = train_model(
        model, train, val, device, args.epochs, args.batch_size, args.learning_rate
    )
    actual, pred, metrics = evaluate(model, test, scaler, device)

    out_dir = Path(args.output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    torch.save({
        "model_state_dict": model.state_dict(),
        "model_config": {"max_atomic_number": 119, "embedding_dim": 64,
                         "hidden_dim": 64, "num_layers": 2, "dropout": 0.1},
        "target_mean": float(scaler.mean_[0]),
        "target_scale": float(scaler.scale_[0]),
        "cutoff": args.cutoff,
        "rbf_dim": args.rbf_dim,
    }, out_dir / "model.pt")

    with (out_dir / "metrics.json").open("w", encoding="utf-8") as f:
        json.dump({"metrics": metrics, "n_materials_requested": args.n_materials,
                   "n_graphs": len(graphs), "n_train": len(train),
                   "n_validation": len(val), "n_test": len(test),
                   "seed": args.seed}, f, indent=2)

    plt.figure(figsize=(6, 6))
    plt.scatter(actual, pred, alpha=0.65)
    low = float(min(actual.min(), pred.min()))
    high = float(max(actual.max(), pred.max()))
    plt.plot([low, high], [low, high], linestyle="--")
    plt.xlabel("Actual band gap (eV)")
    plt.ylabel("Predicted band gap (eV)")
    plt.title(f"Band-gap prediction | MAE={metrics['mae_eV']:.3f} eV")
    plt.tight_layout()
    plt.savefig(out_dir / "predictions.png", dpi=180)
    plt.close()

    print("\nTest metrics")
    print(json.dumps(metrics, indent=2))
    print(f"Outputs saved to: {out_dir.resolve()}")


if __name__ == "__main__":
    main()
