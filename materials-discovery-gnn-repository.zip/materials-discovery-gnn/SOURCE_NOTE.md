# Source note

This repository is a cleaned, runnable baseline derived from the uploaded Materials Discovery GNN experiment. The original Colab export contained duplicated installation cells, mixed application code, and a hard-coded Materials Project API credential. The credential has not been copied. The training entry point has been reorganized into `src/train.py`; review scientific assumptions and validate the implementation before using it for research conclusions.
